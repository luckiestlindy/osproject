$(document).ready(function () {
    $('.carousel').slick({
        dots: true,
        autoplay: true,
        autoplaySpeed: 3000,
        speed: 500,
        fade: true,
        cssEase: 'linear',
        pauseOnFocus: false,
        mobileFirst: true,
    });
  });
